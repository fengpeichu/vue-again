const gulp = require('gulp');
const webserver = require('gulp-webserver');
const fs = require('fs');
const path = require('path');
const url = require('url');
gulp.task('server', () => {
    gulp.src('.')
        .pipe(webserver({
            port: 3000,
            middleware(req, res, next) {
                if (req.url === '/favicon.ico') {
                    res.end('');
                    return;
                }
                let filename = url.parse(req.url).pathname;
                if (filename === '/api/banner') {
                    res.end(JSON.stringify([{
                        img: '1.png',
                    }, {
                        img: '2.png',
                    }, {
                        img: '3.png',
                    }]))
                } else {
                    filename = filename === '/' ? 'index.html' : filename;
                    res.end(fs.readFileSync(path.join(__dirname, filename)))
                }
            }
        }))
})