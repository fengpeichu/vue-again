// function Banner(parent, options) {
//     this.parent = document.querySelector(parent);
//     this.options = options;
//     this.init();
// }

// Banner.prototype = {
//     constructor: Banner,
//     init() {s
//         alert(1)
//     }
// }

//class let const class import
//class 用来定义构造函数的 

class Banner {
    constructor(parent, options) {
        this.parent = document.querySelector(parent);
        this.options = options;
        this.render();
    }
    render() {
        let { data } = this.options;
        let imgs = data.map(item => this.loadimage('./image/' + item.img));
        Promise.all(imgs).then(imgs => {
            imgs.forEach(item => {
                let div = document.createElement('div');
                div.className = 'swiper-slide';
                div.appendChild(item);
                this.parent.appendChild(div);
            })
        })
    }
    loadimage(src) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                resolve(img)
            }
            img.onerror = () => {
                reject(src)
            }
            img.src = src;
        })
    }
}

let Dialog = class {
    constructor() {
        // this.init()
    }
    init() {
        alert(11);
    }
    static setStyle() {
        alert(222);
    }
}

let dialog = new Dialog('', {
    title: '确定要删除吗？',
    cotent: ['确定', '取消'],
    sureCallback() {

    },
    closeCallback() {

    }
});
dialog.init();

Dialog.setStyle()

// Promise.prototype.then
// Promise.all